package com.phone91.sdk.mvvm.dashboard

/**
 * Created by richa.s 441 on 11/2/2019.
 */
interface Callback {
     fun isMore():Boolean
     fun callService()
}