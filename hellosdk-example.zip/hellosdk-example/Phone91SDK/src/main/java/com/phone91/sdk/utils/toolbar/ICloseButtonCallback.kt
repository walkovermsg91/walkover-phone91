package com.phone91.sdk.utils.toolbar

import android.view.View

interface ICloseButtonCallback {
    fun onToolbarClosePressed(view: View)
}