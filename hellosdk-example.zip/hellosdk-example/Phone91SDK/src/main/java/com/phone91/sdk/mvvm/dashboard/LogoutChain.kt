package com.phone91.sdk.mvvm.dashboard

interface LogoutChain {
    public fun logoutApp()
}