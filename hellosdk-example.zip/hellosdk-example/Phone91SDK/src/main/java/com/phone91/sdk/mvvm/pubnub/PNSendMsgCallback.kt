package com.phone91.sdk.mvvm.pubnub

interface PNSendMsgCallback {
    public fun callback()
}