package com.phone91.sample

import android.app.Application
//import com.phone91.sdk.MyApplication

class MyAppClass : Application() {

    override fun onCreate() {
        super.onCreate()
    }

}