package com.phone91.sdk.utils


class FragmentUtils {

    companion object {

        var isDisableFragmentAnimations = false
    }
}