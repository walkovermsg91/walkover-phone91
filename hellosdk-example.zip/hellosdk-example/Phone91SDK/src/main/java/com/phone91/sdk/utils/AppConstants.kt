package com.phone91.sdk.utils

//import com.organizers.ondemand.model.User


const val HOME_FRAGMENT_TAG = "HomeFragment"
const val TEAM_FRAGMENT_TAG = "TeamFragment"



const val PROFILE = "profile"
const val CODE = "code"





